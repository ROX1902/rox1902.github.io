# Big Colorful Toggle Menu - CSS Only  | CPC

A Pen created on CodePen.io. Original URL: [https://codepen.io/TheMOZZARELLA/pen/ExoNQbG](https://codepen.io/TheMOZZARELLA/pen/ExoNQbG).

Toggleable big overlay menu utilizing CSS only. Animated with keyframes and responsive to desktop, tablet, mobile etc.