# Inward Shadow Pt. 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/smashingmag/pen/abPOwRm](https://codepen.io/smashingmag/pen/abPOwRm).

